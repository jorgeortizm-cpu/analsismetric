import 'package:flutter_test/flutter_test.dart';
import 'package:analisismetric_app/app.dart';

void main() {
  testWidgets('AnalisisMetric carga home', (tester) async {
    await tester.pumpWidget(const AnalisisMetricApp());
    expect(find.text('AnalisisMetric'), findsWidgets);
  });
}
